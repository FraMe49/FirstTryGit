

<ul id="sidebar">
<?php dynamic_sidebar( $sidebar ); ?>
	<?php if ( ! dynamic_sidebar() ) : ?>
		<li><a href='#'>Twitter</a></li>
		<li><a href='#'>Facebook</a></li>
		<li><a href='#'>BitTorrent</a></li>
	<?php endif; ?>

</ul>
