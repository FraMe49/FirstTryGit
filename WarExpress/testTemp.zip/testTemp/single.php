<?php get_header(); ?>
          
      
           
           
<?php if ( have_posts() ) : 

while ( have_posts() ) : the_post();
          

          echo "<div class='row'>";
          echo "<div class='col-md-8 blog-title'>";
          echo the_title();
          echo "</div>";
          echo "</div>";
          
          
          echo "<div class='row blog-main'>";
          echo the_content();
          echo "</div>";
          


           ?>
         <?php endwhile; 
                endif;
          ?>
          <?php comments_template(); ?>
          <div class="row">
          <div class="col-md-12">
          <nav>
            <ul class="pager">
              <li><a href="#">Previous</a></li>
              <li><a href="#">Next</a></li>
            </ul>
          </nav>
          </div>
          </div>
     
     <div class="row">
<?php get_sidebar(); ?>
    </div>



   <?php get_footer(); ?>