<!DOCTYPE html>

<html <?php language_attributes(); ?>>

 <head>

   <meta charset="<?php bloginfo('charset'); ?>">

   <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

   <meta name="description" content="<?php bloginfo('description'); ?>">

   <title><?php bloginfo('name'); ?></title>

   <!-- Bootstrap core CSS -->

   <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">

   <!-- Custom styles for this template -->

   <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">

       <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">

   <?php wp_head(); ?>

 </head>

 <body>

   <div class="blog-masthead">

     <div class="container">

       <nav class="blog-nav">

         <?php

           wp_nav_menu( array(

               'menu'              => 'primary',

               'theme_location'    => 'primary',

               'depth'             => 2,

               'container'         => 'div',

               'container_class'   => 'collapse navbar-collapse',

               'container_id'      => 'bs-example-navbar-collapse-1',

               'menu_class'        => 'nav navbar-nav',

               'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

               'walker'            => new WP_Bootstrap_Navwalker())

           );

       ?>

       </nav>

     </div>

   </div>

   <section class="showcase" style="background-image:url('https://s-media-cache-ak0.pinimg.com/originals/bb/8f/22/bb8f227a01034a193136e6c76281739c.jpg')">

     <div class="container">

       <h1><u>Flow Travel Agency</u></h1>

       <p class="aBitRight">Welcome!</p>

       <a href="blog/" class="btn btn-primary btn-lg">Start</a>

     </div>

   </section>

   <section class="boxes">

     <div class="container">

       <div class="row">

         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-paper-plane" aria-hidden="true"></i>

             <h3>Buy Tickets from Us</h3>

             <p>...and fly to your Destination...</p>

           </div>

         </div>

         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-comments" aria-hidden="true"></i>

             <h3>Meet interesting People</h3>

             <p>...and share Memories..</p>

           </div>

         </div>

         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-camera-retro" aria-hidden="true"></i>

             <h3>Document your travel</h3>

             <p>...and present your Story...</p>

           </div>

         </div>

       </div>

     </div>

   </section>


<?php get_footer(); ?>