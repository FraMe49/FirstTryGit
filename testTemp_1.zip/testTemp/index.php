<?php get_header(); ?>
          
      
           
           
<?php if ( have_posts() ) : 

while ( have_posts() ) : the_post();
          

          echo "<div class='row'>";
          echo "<div class='col-md-8 blog-title'>";
          echo the_title();
          echo "</div>";
          echo "</div>";
          
          
          echo "<div class='row blog-main'>";
          echo the_content();
          echo "</div>";
          


           ?>
         <?php endwhile; 
                endif;
          ?>
          
          
     
     <div class="row">
     <?php

       if(is_active_sidebar('sidebar')):

       dynamic_sidebar('sidebar');

       endif;

       

?>
<?php get_sidebar(); ?>
    </div>


    </div>
   <?php get_footer(); ?>