

<ul id="sidebar">
<?php dynamic_sidebar( $sidebar ); ?>
	<?php if ( ! dynamic_sidebar() ) : ?>
		
	<?php endif; ?>

</ul>
